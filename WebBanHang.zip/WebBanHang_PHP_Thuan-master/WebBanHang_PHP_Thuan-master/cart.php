<div class="container-fluid form" style="padding: 20px">
	<div class="row">
		<div class="col-sm-3">
		</div>
		<div class="col-sm-6">
			<legend><h2>Giỏ hàng của bạn</h2></legend>
			<?php require_once 'backend-index.php'; cart_list(); ?>
			<div class="btn btn-secondary btn-block" style="font-size: 27px; margin-bottom: 10px;"><a href="order.php?q=multi">Đặt Hàng</a></div>
		</div>
	</div>
</div>

