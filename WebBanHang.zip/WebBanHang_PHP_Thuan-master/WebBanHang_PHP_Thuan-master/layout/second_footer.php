<footer>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-8" style="text-align: center; padding: 20px 0;">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.23569783274!2d106.69508341423565!3d10.793251561835596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528ca49aeac97%3A0xd5f5346e3a68cc2a!2zMTEzIEhvw6BuZyBTYSwgxJBhIEthbywgUXXhuq1uIDEsIEjhu5MgQ2jDrSBNaW5oLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1509275765221" width="300" height="300" frameborder="0" style="border:0" allowfullscreen id="maps"></iframe>
        </div>
        <div class="col-lg-4" id="contact">
          <h3>Contact</h3>
          <i class="glyphicon glyphicon-map-marker"></i><span> Linh Trung, Thủ Đức, tp.HCM</span><br>
          <i class="glyphicon glyphicon-earphone"></i><span> (08) 391 525</span><br>
          <i class="glyphicon glyphicon-envelope"></i><span> 9XWatch@gmail.com</span><br>
        </div>
        <div class="col-lg-12" id="copyright-txt">
          <b>All right reverse, &#169; copyright of 9XWatch.com</b>
        </div>
      </div>
    </div>
  </footer>
  </body>
</html>