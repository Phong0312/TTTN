[PHP][Product Website] First time php<br>

#Screenshots
- Homepage
<img src="https://github.com/duong97/WebBanHang_PHP_Thuan/blob/master/screenshots/homepage.JPG">

<img src="https://github.com/duong97/WebBanHang_PHP_Thuan/blob/master/screenshots/homepage2.JPG">

- Detail
<img src="https://github.com/duong97/WebBanHang_PHP_Thuan/blob/master/screenshots/detail.JPG">

- Cart
<img src="https://github.com/duong97/WebBanHang_PHP_Thuan/blob/master/screenshots/cart.JPG">

- Payment
<img src="https://github.com/duong97/WebBanHang_PHP_Thuan/blob/master/screenshots/pay.JPG">
